
README for Chapter 6 Sample Solutions

This chapter includes 2 sample solutions:

1. WSStockTraderSecure.sln: Digital Signatures and Encryption in the SOAP Request Message

2. WSStockTraderSecure2.sln: Encryption in the SOAP Response Message

Each solution includes multiple project types. Before opening the solution file 
please run the CreateSampleVdir.vbs script to automatically create any required 
virtual directories. (You can later uninstall these virtual directories using the
DeleteSampleVdir.vbs script).

Other pre-installation requirements for this solution are:

1. Web Services Enhancements Toolkit v2.0

2. Test certificates, available with the WSE 2.0 toolkit

Please refer to Chapter 5 for a detailed discussion of the WSE toolkit, including
how to install and configure the toolkit and the test certificates.

Please refer to Chapter 6 for more information on the sample solution.

The sample solutions were built using the WSE v2.0 Toolkit.

For updated source files, visit: http://www.bluestonepartners.com/soa