using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;

using System.Web.Services.Protocols;
using System.Xml.Serialization;
using System.Security.Permissions;

using Microsoft.Web.Services;
using Microsoft.Web.Services.Timestamp;
using Microsoft.Web.Services.Security;
using Microsoft.Web.Services.Security.Tokens;

namespace StockTrader
{
	/// <summary>
	/// Summary description for StockTrader.
	/// </summary>
	public class StockTrader : System.Web.Services.WebService
	{
		public StockTrader()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		[WebMethod]
		[SoapDocumentMethod(ResponseElementName="StockQuotes")]
		[return:XmlElement("StockQuote")]
		public StockQuote[] StockQuoteRequest( [XmlArray(IsNullable=true), XmlArrayItem("Symbol", IsNullable=false)] string[] symbols )
		{
			// Reject any requests which are not valid SOAP requests
			if (RequestSoapContext.Current == null)
				throw new ApplicationException("Only SOAP requests are permitted.");

			ArrayList list = new ArrayList();
			foreach( String symbol in symbols )
			{
				StockQuote quote    = new StockQuote();
				quote.Symbol        = symbol;
				if( symbol == "FABRIKAM" )
				{
					quote.Name              = "Fabrikam, Inc.";
					quote.Last              = 120.00;
					quote.PreviousChange    = 5.5;
				}
				else
				{
					quote.Name              = "Contoso Corp.";
					quote.Last              = 50.07;
					quote.PreviousChange    = 1.15;
				}
				list.Add( quote );
			}
			return (StockQuote[])list.ToArray(typeof(StockQuote));
		}

	}

	/// <summary>
	/// By implementing UsernameTokenManager we can verify the signature
	/// on messages received.
	/// </summary>
	/// <remarks>
	/// This class includes this demand to ensure that any untrusted
	/// assemblies cannot invoke this code. This helps mitigate
	/// brute-force discovery attacks.
	/// </remarks>
	[SecurityPermissionAttribute(SecurityAction.Demand, Flags=SecurityPermissionFlag.UnmanagedCode)]
	public class CustomUsernameTokenManager : UsernameTokenManager
	{
		/// <summary>
		/// Returns the password or password equivalent for the username provided.
		/// </summary>
		/// <param name="token">The username token</param>
		/// <returns>The password (or password equivalent) for the username</returns>
		protected override string AuthenticateToken( UsernameToken token )
		{
			// This is a very simple manager.
			// In most production systems the following code
			// typically consults an external database of (username,password) pairs where
			// the password is often not the real password but a password equivalent
			// (for example, the hash of the password). Provided that both client and
			// server can generate the same value for a particular username, there is
			// no requirement that the password be the actual password for the user.
			// For this sample the password is simply the reverse of the username.
			byte[] password = System.Text.Encoding.UTF8.GetBytes( token.Username );

			Array.Reverse( password );

			return Convert.ToBase64String( password );
		}
	}

	//
	// This class is an XML Serializable class for a StockQuote complexType
	//
	//  <StockQuote xmlns="http://stockservice.contoso.com/wse/samples/2003/06">
	//      <Symbol>string</Symbol>
	//      <Last>double</Last>
	//      <Date>dateTime</Date>
	//      <Change>double</Change>
	//      <Open>double</Open>
	//      <High>double</High>
	//      <Low>double</Low>
	//      <Volume>long</Volume>
	//      <MarketCap>long</MarketCap>
	//      <PreviousClose>double</PreviousClose>
	//      <PreviousChange>double</PreviousChange>
	//      <Low52Week>double</Low52Week>
	//      <High52Week>double</High52Week>
	//      <Name>string</Name>
	//   </StockQuote>    
	//
	[XmlRoot(Namespace="http://stockservice.contoso.com/wse/samples/2003/06")]
	public class StockQuote
	{
		public String   Symbol;
		public double   Last;
		public DateTime Date;
		public double   Change;
		public double   Open;
		public double   High;
		public double   Low;
		public long     Volume;
		public long     MarketCap;
		public double   PreviousClose;
		public double   PreviousChange;
		public double   Low52Week;
		public double   High52Week;
		public String   Name;
	}

	//
	// This class is an XML Serializable class for a StockSynbols complexType. Note: When this 
	// class is used within the StockQuoteRequest class, it will serialize differently
	// than when it is serialized in a stand-alone fashion.
	//
	// <symbols xmlns="http://stockservice.contoso.com/wse/samples/2003/06">
	//      <Symbol>string</Symbol>
	//      <Symbol>string</Symbol>
	// </symbols>
	//
	[XmlRoot(Namespace="http://stockservice.contoso.com/wse/samples/2003/06")]
	public class StockSymbols
	{
		[XmlElement("Symbol")]          
		public String[] Symbols;                       
	}

	//
	// This class is an XML Serializable class for a StockQuoteRequest complexType
	//
	// <StockQuoteRequest xmlns="http://stockservice.contoso.com/wse/samples/2003/06">
	//      <symbols>
	//          <Symbol>string</Symbol>
	//          <Symbol>string</Symbol>
	//      </symbols>
	// </StockQuoteRequest>
	//
	[XmlRoot(Namespace="http://stockservice.contoso.com/wse/samples/2003/06")]
	public class StockQuoteRequest
	{             
		[XmlArray("symbols")]
		[XmlArrayItem("Symbol")]
		public String[] Symbols;                       
	}

	//
	// This class is an XML Serializable class for a StockQuotes complexType
	//
	// <StockQuotes xmlns="http://stockservice.contoso.com/wse/samples/2003/06">
	//  <StockQuote>
	//      <Symbol>string</Symbol>
	//      <Last>double</Last>
	//      <Date>dateTime</Date>
	//      <Change>double</Change>
	//      <Open>double</Open>
	//      <High>double</High>
	//      <Low>double</Low>
	//      <Volume>long</Volume>
	//      <MarketCap>long</MarketCap>
	//      <PreviousClose>double</PreviousClose>
	//      <PreviousChange>double</PreviousChange>
	//      <Low52Week>double</Low52Week>
	//      <High52Week>double</High52Week>
	//      <Name>string</Name>
	//   </StockQuote>
	//  <StockQuote>
	// </StockQuotes>
	//
	public class StockQuotes
	{
		[XmlElement("StockQuote")]
		public StockQuote[] Quotes;    
	}
}
