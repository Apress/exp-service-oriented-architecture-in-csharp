
/*
	This code sample has been adapted from the WSE 2.0 QuickStart Projects
*/
using System;
using System.Text;

using Microsoft.Web.Services2.Security;
using Microsoft.Web.Services2.Security.Tokens;
using Microsoft.Web.Services2.Security.X509;

namespace WSStockTraderClient
{
	/// <summary>
	/// Summary description for StockTraderSecureClient.
	/// </summary>
	public class StockTraderSecureClient
	{
		[STAThread]
		static void Main(string[] args)
		{
			StockTraderSecureClient client = null;

			try
			{
				client = new StockTraderSecureClient();

				// NOTE TO USER: Try out each of these method calls to test digital signing and encryption

				// Method 1: Example for UsernameToken Digital Signing
				client.SignRequestUsingUsernameToken();

				// Method 2: Example for X509 Certificate Digital Signing
				client.SignRequestUsingX509Certificate();

				// Method 3: Digital encryption using X.509 certificate
				client.EncryptRequestUsingX509Certificate();

			}
			catch (Exception e)
			{
				StringBuilder sb = new StringBuilder();
				if (e is System.Web.Services.Protocols.SoapException)
				{
					System.Web.Services.Protocols.SoapException se = e as System.Web.Services.Protocols.SoapException;
					sb.Append("SOAP-Fault code: " + se.Code.ToString());
					sb.Append("\n");
				}
				if (e != null)
				{
					sb.Append(e.ToString());
				}
				Console.WriteLine("*** Exception Raised ***");
				Console.WriteLine(sb.ToString());
				Console.WriteLine("************************");  
			}

			Console.WriteLine( "" );
			Console.WriteLine("Press [Enter] key to continue...");
			Console.ReadLine();
		}

		public void EncryptRequestUsingX509Certificate()
		{
			// Retrieve the X509 certificate from the CurrentUserStore certificate store
			X509SecurityToken token = GetEncryptionToken();

			if (token == null) throw new ApplicationException("Unable to obtain security key.");

			StockTraderServiceWse serviceProxy = new StockTraderServiceWse();

			// Add the signature element to a security section on the request to sign the request
			serviceProxy.RequestSoapContext.Security.Elements.Add( new EncryptedData( token ) );

			// Call the Web service RequestQuote() method
			Console.WriteLine("Calling {0}", serviceProxy.Url);
			Quote strQuote = serviceProxy.RequestQuote("MSFT");

			// Results
			Console.WriteLine("Web Service call to EncryptRequestUsingX509Certificate() successful. Result:");
			Console.WriteLine( " " );
			Console.WriteLine( "Symbol: " + strQuote.Symbol );
			Console.WriteLine( "Price:  " + strQuote.Last );
			Console.WriteLine( "Change: " + strQuote.PercentChange + "%");
			Console.WriteLine( " " );
		}

		public void SignRequestUsingX509Certificate()
		{
			// Retrieve the X509 certificate from the CurrentUserStore certificate store
			X509SecurityToken token = GetSigningToken();

			if (token == null) throw new ApplicationException("Unable to obtain security token.");

			StockTraderServiceWse serviceProxy = new StockTraderServiceWse();

			// Add the signature element to a security section on the request to sign the request
			serviceProxy.RequestSoapContext.Security.Tokens.Add( token );
			serviceProxy.RequestSoapContext.Security.Elements.Add( new MessageSignature( token ) );

			// Call the Web service RequestQuote() method
			Console.WriteLine("Calling {0}", serviceProxy.Url);
			Quote strQuote = serviceProxy.RequestQuote("MSFT");

			// Results
			Console.WriteLine("Web Service call to SignRequestUsingX509Certificate() successful. Result:");
			Console.WriteLine( " " );
			Console.WriteLine( "Symbol: " + strQuote.Symbol );
			Console.WriteLine( "Price:  " + strQuote.Last );
			Console.WriteLine( "Change: " + strQuote.PercentChange + "%");
			Console.WriteLine( " " );
		}

		public void SignRequestUsingUsernameToken()
		{
			string username      = Environment.UserName; //"myUsername"; // Hardcoded username
			byte[] passwordBytes = System.Text.Encoding.UTF8.GetBytes( username );
			Array.Reverse( passwordBytes );
			string passwordEquivalent = Convert.ToBase64String( passwordBytes );
			
			SecurityToken token = new UsernameToken(username, passwordEquivalent, PasswordOption.SendHashed);

//			// cache the username token for response encryption
//			UsernameTokenCache.GlobalCache.Add(token as UsernameToken);

//			// Assign a random nonce value to the security token
//			Microsoft.Web.Services2.Security.Nonce objNonce = new Nonce(34);
//			token.Id = objNonce.Value;

			StockTraderServiceWse serviceProxy = new StockTraderServiceWse();

			// Add the signature element to a security section on the request to sign the request
			serviceProxy.RequestSoapContext.Security.Tokens.Add( token );
			serviceProxy.RequestSoapContext.Security.Elements.Add( new MessageSignature( token ) );

			// Call the Web service RequestQuote() method
			Console.WriteLine("Calling {0}", serviceProxy.Url);
			Quote strQuote = serviceProxy.RequestQuote("MSFT");

			// Results
			Console.WriteLine("Web Service call to SignRequestUsingUsernameToken() successful. Result:");
			Console.WriteLine( " " );
			Console.WriteLine( "Symbol: " + strQuote.Symbol );
			Console.WriteLine( "Price:  " + strQuote.Last );
			Console.WriteLine( "Change: " + strQuote.PercentChange + "%");
			Console.WriteLine( " " );
		}

		private X509SecurityToken GetSigningToken()
		{
			// NOTE: If you use the WSE 2.0 sample certificates then you should not need to change these IDs
			string ClientBase64KeyId = "gBfo0147lM6cKnTbbMSuMVvmFY4=";

			X509SecurityToken token = null;

			// Open the CurrentUser Certificate Store
			X509CertificateStore store;
			store = X509CertificateStore.CurrentUserStore( X509CertificateStore.MyStore );
			if ( store.OpenRead() )
			{
				X509CertificateCollection certs = store.FindCertificateByKeyIdentifier( Convert.FromBase64String( ClientBase64KeyId ) );

				if (certs.Count > 0)
				{
					// Get the first certificate in the collection
					token = new X509SecurityToken( ((X509Certificate) certs[0]) );
				}
			}
			return token;
		}

		private X509SecurityToken GetEncryptionToken()
		{
			// NOTE: If you use the WSE 2.0 sample certificates then you should not need to change these IDs
			string ServerBase64KeyId = "bBwPfItvKp3b6TNDq+14qs58VJQ=";

			X509SecurityToken token = null;

			// Open the CurrentUser Certificate Store
			X509CertificateStore store;
			store = X509CertificateStore.CurrentUserStore( X509CertificateStore.MyStore );
			if( !store.OpenRead() ) return null;

			// Find the certificate based on the server's base64 key identifier
			X509CertificateCollection certs = store.FindCertificateByKeyIdentifier( Convert.FromBase64String( ServerBase64KeyId ) );

			if (certs.Count > 0)
			{
				// Get the first certificate in the collection
				token = new X509SecurityToken( ((X509Certificate) certs[0]) );
			}

			return token;
		}

	}
}
