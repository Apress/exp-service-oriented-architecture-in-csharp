using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;

using System.Web.Services.Protocols;
using System.Web.Services.Description;
using System.Xml.Serialization;

using Microsoft.Web.Services2;
using Microsoft.Web.Services2.Security;
using Microsoft.Web.Services2.Security.Tokens;
using Microsoft.Web.Services2.Security.X509;

using System.Security.Permissions;

using StockTraderTypes;

namespace StockTrader
{
	/// <summary>
	/// Summary description for StockTraderService
	/// </summary>
	[WebService(Namespace = "http://www.bluestonepartners.com/schemas/StockTrader")]
	public class StockTraderService : System.Web.Services.WebService, StockTraderTypes.IStockTrader
	{
	
		[WebMethod()]
		[SoapDocumentMethod(RequestNamespace="http://www.bluestonepartners.com/schemas/StockTrader/", ResponseNamespace="http://www.bluestonepartners.com/schemas/StockTrader/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Bare)]
		[return: XmlElement(ElementName = "Quote", Namespace = "http://www.bluestonepartners.com/schemas/StockTrader/")]
		public Quote RequestQuote(string Symbol)
		{
			SoapContext requestContext = RequestSoapContext.Current;
			SoapContext responseContext = ResponseSoapContext.Current;

			// Get the signing certificate
			X509SecurityToken token = GetEncryptionToken(requestContext);

			if( token != null )
			{
				// Encrypt the response with the key in the request.
				responseContext.Security.Elements.Add( new EncryptedData( token ) );
				//throw new ApplicationException(token.Certificate.GetName() );
			}
			else
			{
				throw new ApplicationException("Unable to retrieve the encrypting certificate." );
			}
			
			// Step 2: Create a new Quote object, but only populate it if signature is valid
			Quote q = new Quote();
			if (Symbol.ToUpper() == "MSFT")
			{
				q.Symbol = Symbol; // Sample Quote
				q.Company = "Microsoft Corporation";
				q.DateTime = "11/17/2003 16:00:00";
				q.Last = 25.15;
				q.Previous_Close = 25.49;
				q.Change = -0.36;
				q.PercentChange = -0.0137;
			}
			else
			{
				q.Symbol = "INTC"; // Sample Quote
				q.Company = "Intel Corporation";
				q.DateTime = "11/17/2003 16:00:00";
				q.Last = 32.23;
				q.Previous_Close = 32.81;
				q.Change = -0.58;
				q.PercentChange = -0.0174;
			}
			return q; // Return a Quote object
		}

		[WebMethod()]
		[SoapDocumentMethod(RequestNamespace="http://www.bluestonepartners.com/schemas/StockTrader/", ResponseNamespace="http://www.bluestonepartners.com/schemas/StockTrader/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Bare)]
		[return: XmlElement("Trade", Namespace = "http://www.bluestonepartners.com/schemas/StockTrader/")]
		public Trade PlaceTrade(string Account, string Symbol, int Shares, System.Double Price, TradeType tradeType)
		{
			Trade t = new Trade();
			t.TradeID = System.Guid.NewGuid().ToString();
			t.OrderDateTime = "11/17/2003 18:30:00";
			t.Symbol = Symbol;
			t.Shares = Shares;
			t.Price = Price;
			t.tradeType = tradeType;
			t.tradeStatus = TradeStatus.Ordered; // Initialize Trade status to Ordered

			// Implement code here to persist trade details to the database by account number and trade ID
			// <-- Code goes here -->

			return t; // Return the Trade object
		}

		[WebMethod()]
		[SoapDocumentMethod(RequestNamespace="http://www.bluestonepartners.com/schemas/StockTrader/", ResponseNamespace="http://www.bluestonepartners.com/schemas/StockTrader/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Bare)]
		[return: XmlElement("Trade", Namespace = "http://www.bluestonepartners.com/schemas/StockTrader/")]
		public Trade RequestTradeDetails(string Account, string TradeID)
		{
			// Lookup the current trade by account number and Trade ID
			// Return the results in a Trade object
			Trade t = new Trade();
			t.TradeID = "123456";
			t.Symbol = "MSFT";
			t.Shares = 120;
			t.Price = 25.15;
			t.tradeType = TradeType.Bid;
			t.tradeStatus = TradeStatus.Filled;
			return t;
		}
		
		[WebMethod()]
		[SoapDocumentMethod(RequestNamespace="http://www.bluestonepartners.com/schemas/StockTrader/", ResponseNamespace="http://www.bluestonepartners.com/schemas/StockTrader/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Bare)]
		[return: XmlElement("Trades", Namespace = "http://www.bluestonepartners.com/schemas/StockTrader/")]
		public Trades RequestAllTradesSummary(string Account)
		{
			// Return a Trades object that summarizes all Bid and Ask trades for the current account number
			// Lookup all current trades by account number
			// Return the results in a Trades object
			Trades t = new Trades();
			t.Account = Account; // Assign the current account number

			ArrayList arrBids = new ArrayList();
			ArrayList arrAsks = new ArrayList();

			// Implement code here to retrieve all trades from the database
			// <-- Code goes here -->

			Trade t1 = new Trade(); // Sample Bid Trade
			t1.tradeType = TradeType.Bid;
			t1.Symbol = "MSFT";
			t1.Shares = 120;
			t1.Price = 25.15;
			t1.tradeStatus = TradeStatus.Filled;
			arrBids.Add(t1);

			Trade t2 = new Trade(); // Sample Ask Trade
			t1.tradeType = TradeType.Ask;
			t1.Symbol = "INTC";
			t1.Shares = 80;
			t1.Price = 32.23;
			t1.tradeStatus = TradeStatus.Filled;
			arrAsks.Add(t2);

			t.Bids = (Trade[])arrBids.ToArray(typeof(Trade)); // Transfer the arraylist of Bids to the Trades object's Bids collection
			t.Asks = (Trade[])arrAsks.ToArray(typeof(Trade)); // Transfer the arraylist of Asks to the Trades object's Asks collection

			return t; // Return the Trades object
		}

		private X509SecurityToken GetEncryptionToken(SoapContext requestContext)
		{
			X509SecurityToken x509token = null;

			// Look for a digital signature, which contains the token that the Web Service will use for encrypting the response
			if ( requestContext.Security.Tokens.Count > 0 )
			{
				//
				// Check for a Signature that signed the soap Body and uses an x509 token.
				//
				foreach ( ISecurityElement element in requestContext.Security.Elements )
				{
					MessageSignature signature = element as MessageSignature;

					// The signature we seek signed the soap Body
					if ( signature != null && (signature.SignatureOptions & SignatureOptions.IncludeSoapBody) != 0 )
					{
						x509token = signature.SigningToken as X509SecurityToken;

						if ( x509token != null )
						{
							// Return the certificate for encrypting the response
							// if it is capable of encryption
							X509Certificate cert = x509token.Certificate;
							if ( !cert.SupportsDataEncryption )
							{
								//return x509token;
								x509token = null; // Reset x509token to null, so it does not get used
							}
						}
					}
				}
			}
			return x509token;
		}

	}
}
