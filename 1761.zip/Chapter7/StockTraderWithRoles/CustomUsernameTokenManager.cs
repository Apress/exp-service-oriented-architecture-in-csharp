

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;

using System.Web.Services.Protocols;
using System.Web.Services.Description;
using System.Xml.Serialization;

using Microsoft.Web.Services2;
using Microsoft.Web.Services2.Security;
using Microsoft.Web.Services2.Security.Tokens;

using System.Net;
using System.Security;
using System.Security.Principal;
using System.Security.Permissions;

using StockTraderTypes;

namespace StockTrader
{
	/// <summary>
	/// By implementing UsernameTokenManager we can verify the signature
	/// on messages received.
	/// </summary>
	/// <remarks>
	/// This class includes this demand to ensure that any untrusted
	/// assemblies cannot invoke this code. This helps mitigate
	/// brute-force discovery attacks.
	/// </remarks>
	[SecurityPermissionAttribute(SecurityAction.Demand, Flags=SecurityPermissionFlag.UnmanagedCode)]
	public class CustomUsernameTokenManager : UsernameTokenManager
	{
		/// <summary>
		/// Returns the password or password equivalent for the username provided.
		/// </summary>
		/// <param name="token">The username token</param>
		/// <returns>The password (or password equivalent) for the username</returns>
		protected override string AuthenticateToken( UsernameToken token )
		{
			byte[] password = System.Text.Encoding.UTF8.GetBytes( token.Username );
			Array.Reverse( password );
			return Convert.ToBase64String( password );
		}
	}
	
}
