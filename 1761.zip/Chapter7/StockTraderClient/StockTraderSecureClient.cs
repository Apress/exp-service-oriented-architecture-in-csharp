
/*
	This code sample has been adapted from the WSE 2.0 QuickStart Projects
*/
using System;
using System.Text;

using Microsoft.Web.Services2;
using Microsoft.Web.Services2.Security;
using Microsoft.Web.Services2.Security.Tokens;
using Microsoft.Web.Services2.Security.X509;
using Microsoft.Web.Services2.Security.Policy;

using StockTraderSecurePolicy;

namespace StockTraderClient
{
	/// <summary>
	/// Summary description for StockTraderSecureClient.
	/// </summary>
	public class StockTraderSecureClient
	{
		[STAThread]
		static void Main(string[] args)
		{
			StockTraderSecureClient client = null;

			try
			{
				client = new StockTraderSecureClient();

				// Sign the request message with an X509 Certificate
				client.EncryptRequestUsingX509Certificate();

			}
			catch (Exception e)
			{
				StringBuilder sb = new StringBuilder();
				if (e is System.Web.Services.Protocols.SoapException)
				{
					System.Web.Services.Protocols.SoapException se = e as System.Web.Services.Protocols.SoapException;
					sb.Append("SOAP-Fault code: " + se.Code.ToString());
					sb.Append("\n");
				}
				if (e != null)
				{
					sb.Append(e.ToString());
				}
				Console.WriteLine("*** Exception Raised ***");
				Console.WriteLine(sb.ToString());
				Console.WriteLine("************************");  
			}

			Console.WriteLine( "" );
			Console.WriteLine("Press [Enter] key to continue...");
			Console.ReadLine();
		}

		public void EncryptRequestUsingX509Certificate()
		{
			// Retrieve the X509 certificate from the CurrentUserStore certificate store
			X509SecurityToken token = GetEncryptionToken(); //GetSigningToken();

			if (token == null) throw new ApplicationException("Unable to obtain security token.");

			StockTraderServiceWse serviceProxy = new StockTraderServiceWse();

//			// Add the signature element to a security section on the request to sign the request
//			serviceProxy.RequestSoapContext.Security.Tokens.Add( token );
//			serviceProxy.RequestSoapContext.Security.Elements.Add( new MessageSignature( token ) );

			// Add the token to a security section on the request to encrypt the request
			serviceProxy.RequestSoapContext.Security.Elements.Add( new EncryptedData( token ) );

			// Rather, use the SecurityTokenCache since that's one of the places
			// where the policy enforcer will look for security tokens.
//			PolicyEnforcementSecurityTokenCache.GlobalCache.Add( token );

			// Call the Web service RequestQuote() method
			Console.WriteLine("Calling {0}", serviceProxy.Url);
			Quote strQuote = serviceProxy.RequestQuote("MSFT");

			// Results
			Console.WriteLine("Web Service call successful. Result:");
			Console.WriteLine( " " );
			Console.WriteLine( "Symbol: " + strQuote.Symbol );
			Console.WriteLine( "Price:  " + strQuote.Last );
			Console.WriteLine( "Change: " + strQuote.PercentChange + "%");
		}

		private X509SecurityToken GetSigningToken()
		{
			// NOTE: If you use the WSE 2.0 sample certificates then you should not need to change these IDs
			string ClientBase64KeyId = "gBfo0147lM6cKnTbbMSuMVvmFY4=";

			X509SecurityToken token = null;

			// Open the CurrentUser Certificate Store
			X509CertificateStore store;
			store = X509CertificateStore.CurrentUserStore( X509CertificateStore.MyStore );
			if( !store.OpenRead() ) return null;
			X509CertificateCollection certs = store.FindCertificateByKeyIdentifier( Convert.FromBase64String( ClientBase64KeyId ) );

			if (certs.Count > 0)
			{
				// Get the first certificate in the collection
				token = new X509SecurityToken( ((X509Certificate) certs[0]) );
			}
			return token;
		}

		private X509SecurityToken GetEncryptionToken()
		{
			// NOTE: If you use the WSE 2.0 sample certificates then you should not need to change these IDs
			string ServerBase64KeyId = "bBwPfItvKp3b6TNDq+14qs58VJQ=";

			X509SecurityToken token = null;

			// Open the CurrentUser Certificate Store
			X509CertificateStore store;
			store = X509CertificateStore.CurrentUserStore( X509CertificateStore.MyStore );
			if( !store.OpenRead() ) return null;

			// Find the certificate based on the server's base64 key identifier
			X509CertificateCollection certs = store.FindCertificateByKeyIdentifier( Convert.FromBase64String( ServerBase64KeyId ) );

			if (certs.Count > 0)
			{
				// Get the first certificate in the collection
				token = new X509SecurityToken( ((X509Certificate) certs[0]) );
			}

			return token;
		}

	}
}

