
README for WSDL.EXE and StockTrader.wsdl

Note: The StockTrader.wsdl file in this folder is compliant
with the WS-I Basic Profile 1.0.

To generate a proxy file from StockTrader.wsdl, type 
the following at the command prompt:

wsdl /o:StockTraderProxy.cs StockTrader.wsdl


To generate a proxy file from StockTrader.wsdl, type
the following at the command prompt:

wsdl /server /o:StockTraderStub.cs StockTrader.wsdl