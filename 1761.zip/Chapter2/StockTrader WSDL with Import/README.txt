
README for WSDL.EXE and StockTrader.wsdl and StockTrader.xsd

NOTE: The StockTrader.wsdl file in this folder is not compliant 
with the WS-I Basic Profile. It contains an <import> tag to pull
in type definitions from an external XSD schema file located at:
http://www.bluestonepartners.com/schemas/StockTrader.xsd.
You do not need to have the XSD file in the same folder as the 
WSDL file when running the WSDL.EXE utility, as long as you have 
access to the public location of StockTrader.xsd. The WSDL file 
is provided in this format for illustration purposes only.

To generate a proxy file from StockTrader.wsdl, type 
the following at the command prompt:

wsdl /o:StockTraderProxy.cs StockTrader.wsdl StockTrader.xsd


To generate a proxy file from StockTrader.wsdl, type
the following at the command prompt:

wsdl /server /o:StockTraderStub.cs StockTrader.wsdl StockTrader.xsd