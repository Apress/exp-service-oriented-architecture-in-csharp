
README for Chapter 2 Sample Solutions

This chapter does not include any VS.NET projects. Instead, it contains:

1. Folder: StockTrader WSDL Only

	A. StockTrader.wsdl: The WSDL document for the StockTrader Web service
			     including embedded type definitions

2. Folder: StockTrader WSDL + XSD

	A. StockTrader.wsdl: The WSDL document for the StockTrader Web service
			     without any embedded type definitions

	B. StockTrader.xsd:  The XSD schema for the StockTrader Web service

3. Folder: StockTrader WSDL with Import

	A. StockTrader.wsdl: The WSDL document for the StockTrader Web service
			     using the <imports> tag in place of embedded type definitions

Please refer to Chapter 2 for more information on these files.

For updated source files, visit: http://www.bluestonepartners.com/soa