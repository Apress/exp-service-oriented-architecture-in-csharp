
README for Chapter 4 Sample Solutions

This chapter includes 2 sample solutions:

1. StockTraderAdvanced.sln

2. StockTraderAdvancedWithServiceAgent.sln

Each solution includes multiple project types. Before opening the solution files 
please run the CreateSampleVdir.vbs script to automatically create any required 
virtual directories. (You can later uninstall these virtual directories using the
DeleteSampleVdir.vbs script).

The sample solutions were built using the WSE v2.0 Toolkit.

Please refer to Chapter 4 for more information on the sample solutions.

For updated source files, visit: http://www.bluestonepartners.com/soa