
README for Chapter 8 Sample Solutions

This chapter includes 1 sample solution:

1. WSSecureConversation.sln

The solution includes multiple project types. Before opening the solution file 
please run the CreateSampleVdir.vbs script to automatically create any required 
virtual directories. (You can later uninstall these virtual directories using the
DeleteSampleVdir.vbs script).

The sample solution was built using the WSE v2.0 Toolkit.

Please refer to Chapter 8 for more information on the sample solution.

For updated source files, visit: http://www.bluestonepartners.com/soa